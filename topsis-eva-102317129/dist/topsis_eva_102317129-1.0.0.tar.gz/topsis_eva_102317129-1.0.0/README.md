#TOPSIS Python Package

##Installation
pip install topsis-eva-102317129

##Usage
topsis data.csv "1,1,1,1,2" "+,+,+,-,+" result.csv
